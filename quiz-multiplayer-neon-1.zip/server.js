const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const MAX_PLAYERS = 30;
const INTRO_MS = 3000;
const LEADERBOARD_MS = 5000;

app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true }));

const questionBank = [
  { level: 1, text: "Qual é a capital do Brasil?", options: ["Rio de Janeiro", "Brasília"], correct: 1 },
  { level: 1, text: "Qual é o maior oceano do planeta?", options: ["Oceano Atlântico", "Oceano Pacífico"], correct: 1 },
  { level: 2, text: "Qual elemento químico tem o símbolo Au?", options: ["Prata", "Ouro", "Cobre"], correct: 1 },
  { level: 2, text: "Qual é o planeta mais próximo do Sol?", options: ["Vênus", "Mercúrio", "Marte"], correct: 1 },
  { level: 3, text: "Em que ano ocorreu a queda do Império Romano do Ocidente?", options: ["395 d.C.", "476 d.C.", "1453 d.C.", "527 d.C."], correct: 1 },
  { level: 3, text: "Qual país é conhecido por ter o maior número de ilhas?", options: ["Finlândia", "Suécia", "Indonésia", "Canadá"], correct: 1 }
];

const levelConfig = {
  1: { time: 20 },
  2: { time: 15 },
  3: { time: 12 }
};

const rooms = new Map();
const socketRoom = new Map();

function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function makeRoomId() {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let id;
  do {
    id = Array.from({ length: 6 }, () => alphabet[Math.floor(Math.random() * alphabet.length)]).join("");
  } while (rooms.has(id));
  return id;
}

function createRoom(isPrivate) {
  const id = makeRoomId();
  const questionsByLevel = {};
  for (const level of [1, 2, 3]) {
    questionsByLevel[level] = shuffle(questionBank.filter(q => q.level === level));
  }
  const room = {
    id,
    isPrivate,
    players: [],
    hostId: null,
    status: "lobby",
    currentLevel: 1,
    questionIndex: 0,
    timeLeft: levelConfig[1].time,
    currentQuestion: null,
    questionsByLevel,
    timer: null,
    transitionTimer: null,
    questionToken: 0
  };
  rooms.set(id, room);
  return room;
}

function clearRoomTimers(room) {
  if (room.timer) clearInterval(room.timer);
  if (room.transitionTimer) clearTimeout(room.transitionTimer);
  room.timer = null;
  room.transitionTimer = null;
}

function publicRoomState(room) {
  return {
    roomId: room.id,
    isPrivate: room.isPrivate,
    status: room.status,
    hostId: room.hostId,
    players: room.players.map(p => ({
      nick: p.nick,
      avatar: p.avatar,
      score: p.score,
      isHost: p.id === room.hostId,
      answered: p.answered
    })),
    total: room.players.length,
    maxPlayers: MAX_PLAYERS
  };
}

function emitLobby(room) {
  io.to(room.id).emit("update_lobby", publicRoomState(room));
}

function emitError(socket, message) {
  socket.emit("error_msg", message);
}

function roomForSocket(socketId) {
  const roomId = socketRoom.get(socketId);
  return roomId ? rooms.get(roomId) : null;
}

function findPublicRoom() {
  for (const room of rooms.values()) {
    if (!room.isPrivate && room.status === "lobby" && room.players.length < MAX_PLAYERS) return room;
  }
  return createRoom(false);
}

function removePlayer(socket) {
  const room = roomForSocket(socket.id);
  if (!room) return;

  room.players = room.players.filter(p => p.id !== socket.id);
  socketRoom.delete(socket.id);
  socket.leave(room.id);

  if (room.players.length === 0) {
    clearRoomTimers(room);
    rooms.delete(room.id);
    return;
  }

  if (room.hostId === socket.id) {
    room.hostId = room.players[0].id;
    io.to(room.id).emit("host_changed", {
      nick: room.players[0].nick,
      message: `${room.players[0].nick} agora é o Host da sala.`
    });
  }

  if (room.status === "question" && room.players.every(p => p.answered)) {
    clearInterval(room.timer);
    room.timer = null;
    nextQuestionOrLevel(room.id, room.questionToken);
  }
  emitLobby(room);
}

function joinRoom(socket, data = {}) {
  if (socketRoom.has(socket.id)) {
    emitError(socket, "Você já está em uma sala. Atualize a página para entrar em outra.");
    return;
  }

  const nick = String(data.nick || "").trim().slice(0, 15);
  const avatar = String(data.avatar || "🎮").trim().slice(0, 8) || "🎮";
  if (!nick) {
    emitError(socket, "Digite um apelido antes de entrar.");
    return;
  }

  let room;
  const customRoomId = String(data.customRoomId || "").trim().toUpperCase();
  const roomType = data.roomType === "private" ? "private" : "public";

  if (roomType === "private" && customRoomId) {
    room = rooms.get(customRoomId);
    if (!room || !room.isPrivate) {
      emitError(socket, "Sala privada não encontrada. Confira o código.");
      return;
    }
    if (room.status !== "lobby") {
      emitError(socket, "Esta sala já está com uma partida em andamento ou encerrada.");
      return;
    }
  } else if (roomType === "private") {
    room = createRoom(true);
  } else {
    room = findPublicRoom();
  }

  if (room.players.length >= MAX_PLAYERS) {
    emitError(socket, "Sala cheia. O limite é de 30 jogadores.");
    return;
  }

  const player = { id: socket.id, nick, avatar, score: 0, answered: false };
  room.players.push(player);
  if (!room.hostId) room.hostId = socket.id;

  socketRoom.set(socket.id, room.id);
  socket.join(room.id);
  socket.emit("joined_room", {
    roomId: room.id,
    isPrivate: room.isPrivate,
    isHost: room.hostId === socket.id
  });
  emitLobby(room);
}

function startGame(socket) {
  const room = roomForSocket(socket.id);
  if (!room) return emitError(socket, "Entre em uma sala antes de iniciar.");
  if (room.hostId !== socket.id) return emitError(socket, "Somente o Host pode iniciar a partida.");
  if (room.status !== "lobby") return emitError(socket, "A partida já foi iniciada.");
  if (room.players.length < 1) return emitError(socket, "É necessário pelo menos um jogador.");

  clearRoomTimers(room);
  room.status = "intro";
  room.currentLevel = 1;
  room.questionIndex = 0;
  room.players.forEach(p => { p.score = 0; p.answered = false; });
  startLevel(room.id);
}

function startLevel(roomId) {
  const room = rooms.get(roomId);
  if (!room || room.players.length === 0) return;
  room.status = "intro";
  io.to(roomId).emit("level_intro", {
    level: room.currentLevel,
    time: levelConfig[room.currentLevel]?.time || 10,
    message: `Prepare-se para o nível ${room.currentLevel}!`
  });
  room.transitionTimer = setTimeout(() => {
    room.transitionTimer = null;
    sendQuestion(roomId);
  }, INTRO_MS);
}

function sendQuestion(roomId) {
  const room = rooms.get(roomId);
  if (!room || room.players.length === 0) return;

  const questions = room.questionsByLevel[room.currentLevel] || [];
  if (room.questionIndex >= questions.length) {
    finishLevel(roomId);
    return;
  }

  room.status = "question";
  room.players.forEach(p => { p.answered = false; });
  room.currentQuestion = questions[room.questionIndex];
  room.timeLeft = levelConfig[room.currentLevel]?.time || 10;
  const token = ++room.questionToken;

  io.to(roomId).emit("new_question", {
    text: room.currentQuestion.text,
    options: room.currentQuestion.options,
    questionNumber: room.questionIndex + 1,
    totalQuestions: questions.length,
    level: room.currentLevel,
    timeLimit: room.timeLeft
  });
  emitLobby(room);

  room.timer = setInterval(() => {
    if (!rooms.has(roomId) || room.questionToken !== token || room.status !== "question") return;
    room.timeLeft = Math.max(0, room.timeLeft - 1);
    io.to(roomId).emit("timer_tick", room.timeLeft);
    if (room.timeLeft <= 0) {
      clearInterval(room.timer);
      room.timer = null;
      nextQuestionOrLevel(roomId, token);
    }
  }, 1000);
}

function submitAnswer(socket, data = {}) {
  const room = roomForSocket(socket.id);
  if (!room || room.status !== "question" || !room.currentQuestion) return;
  const player = room.players.find(p => p.id === socket.id);
  if (!player || player.answered) return;

  const optionIndex = Number(data.optionIndex);
  if (!Number.isInteger(optionIndex) || optionIndex < 0 || optionIndex >= room.currentQuestion.options.length) {
    return emitError(socket, "Resposta inválida.");
  }

  player.answered = true;
  const correct = optionIndex === room.currentQuestion.correct;
  if (correct) {
    player.score += Math.round((100 + room.timeLeft * 10) * room.currentLevel);
  }
  socket.emit("answer_result", { correct, score: player.score });
  emitLobby(room);

  if (room.players.length > 0 && room.players.every(p => p.answered)) {
    const token = room.questionToken;
    if (room.timer) clearInterval(room.timer);
    room.timer = null;
    nextQuestionOrLevel(room.id, token);
  }
}

function nextQuestionOrLevel(roomId, token) {
  const room = rooms.get(roomId);
  if (!room || room.status !== "question" || room.questionToken !== token) return;
  room.status = "transition";
  room.questionIndex += 1;
  room.transitionTimer = setTimeout(() => {
    room.transitionTimer = null;
    if (!rooms.has(roomId)) return;
    sendQuestion(roomId);
  }, 700);
}

function finishLevel(roomId) {
  const room = rooms.get(roomId);
  if (!room) return;
  clearRoomTimers(room);
  room.status = "leaderboard";
  const leaderboard = [...room.players]
    .sort((a, b) => b.score - a.score)
    .map((p, index) => ({
      position: index + 1, nick: p.nick, avatar: p.avatar, score: p.score
    }));

  io.to(roomId).emit("show_leaderboard", {
    level: room.currentLevel,
    leaderboard
  });

  room.transitionTimer = setTimeout(() => {
    room.transitionTimer = null;
    if (!rooms.has(roomId)) return;
    const nextLevel = room.currentLevel + 1;
    if (room.questionsByLevel[nextLevel]?.length) {
      room.currentLevel = nextLevel;
      room.questionIndex = 0;
      startLevel(roomId);
    } else {
      room.status = "finished";
      io.to(roomId).emit("game_over", { finalLeaderboard: leaderboard });
      emitLobby(room);
      // A sala permanece disponível para o ranking final até os jogadores saírem.
    }
  }, LEADERBOARD_MS);
}

io.on("connection", socket => {
  socket.on("register_player", data => joinRoom(socket, data));
  socket.on("start_game", () => startGame(socket));
  socket.on("submit_answer", data => submitAnswer(socket, data));
  socket.on("disconnect", () => removePlayer(socket));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`Quiz Multiplayer rodando na porta ${PORT}`);
});
