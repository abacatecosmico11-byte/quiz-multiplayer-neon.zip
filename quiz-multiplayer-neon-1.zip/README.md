# Quiz Multiplayer Neon

Projeto Node.js + Express + Socket.IO com visual neon responsivo para celular e computador.

## Recursos
- Salas públicas e privadas independentes, com códigos de convite.
- Host por sala, jogadores/avatares e placar em tempo real.
- Animações CSS, feedback visual, temporizador e efeitos sonoros gerados no navegador.
- Perguntas e pontuação calculadas no servidor.
- Endpoint `/health` para monitoramento.

## Executar localmente
1. Instale Node.js 18 ou superior.
2. Extraia o ZIP e abra a pasta `quiz-multiplayer-neon`.
3. Rode `npm install`.
4. Rode `npm start`.
5. Acesse `http://localhost:3000` em mais de um dispositivo na mesma rede ou publique em um serviço que suporte Node.js e WebSockets.

## Publicar na internet
Configure o comando de inicialização como `npm start`. Use uma hospedagem Node.js que suporte WebSockets/Socket.IO e mantenha uma única instância enquanto as salas ficam armazenadas em memória. Ao reiniciar o servidor, as salas atuais são perdidas. Para múltiplas instâncias, configure um adaptador Socket.IO e armazenamento compartilhado.

## Observações
- O navegador pode exigir um toque/clique para habilitar áudio.
- Salas e pontuações ficam em memória; ainda não há banco de dados persistente.
